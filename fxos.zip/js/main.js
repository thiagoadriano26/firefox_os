$(function () {

    $(".ui-br").css("border", "none");
    

});